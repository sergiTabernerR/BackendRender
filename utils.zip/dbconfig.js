const config = {
  user: "sergi8881_SQLLogin_1",
  password: "x7ck24kxo6",  
  server: "TRANSPORTESSIMON.mssql.somee.com",
  database: "TRANSPORTESSIMON",
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

module.exports = config;
